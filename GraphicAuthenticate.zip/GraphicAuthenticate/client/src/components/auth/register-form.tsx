import { useState } from "react";
import { useForm } from "react-hook-form";
import { zodResolver } from "@hookform/resolvers/zod";
import { insertUserSchema, InsertUser } from "@shared/schema";
import { Button } from "@/components/ui/button";
import { Input } from "@/components/ui/input";
import {
  Form,
  FormControl,
  FormField,
  FormItem,
  FormLabel,
  FormMessage,
} from "@/components/ui/form";
import { ColorGrid } from "./color-grid";
import { useAuth } from "@/hooks/use-auth";

export function RegisterForm() {
  const { registerMutation } = useAuth();
  const [colorPattern, setColorPattern] = useState<Array<{ color: string; position: number }>>([]);

  const form = useForm<InsertUser>({
    resolver: zodResolver(insertUserSchema),
    defaultValues: {
      username: "",
      password: "",
      confirmPassword: "",
      colorPattern: []
    }
  });

  const onSubmit = (data: InsertUser) => {
    if (colorPattern.length < 4) {
      form.setError("colorPattern", { 
        message: "Please select at least 4 colors in sequence" 
      });
      return;
    }
    
    registerMutation.mutate({
      ...data,
      colorPattern,
      password: colorPattern.map(p => `${p.color}-${p.position}`).join("|")
    });
  };

  return (
    <Form {...form}>
      <form onSubmit={form.handleSubmit(onSubmit)} className="space-y-6">
        <FormField
          control={form.control}
          name="username"
          render={({ field }) => (
            <FormItem>
              <FormLabel>Username</FormLabel>
              <FormControl>
                <Input {...field} />
              </FormControl>
              <FormMessage />
            </FormItem>
          )}
        />

        <div className="space-y-2">
          <FormLabel>Select Color Pattern</FormLabel>
          <ColorGrid 
            onSelect={(selection) => {
              setColorPattern(prev => [...prev, {
                color: selection.color,
                position: selection.position
              }]);
            }}
          />
          <div className="flex gap-2 flex-wrap mt-2">
            {colorPattern.map((item, idx) => (
              <div
                key={idx}
                className="w-6 h-6 rounded"
                style={{ backgroundColor: item.color }}
              />
            ))}
          </div>
          {form.formState.errors.colorPattern && (
            <p className="text-sm font-medium text-destructive">
              {form.formState.errors.colorPattern.message}
            </p>
          )}
        </div>

        <Button 
          type="submit" 
          className="w-full"
          disabled={registerMutation.isPending}
        >
          Register
        </Button>
      </form>
    </Form>
  );
}
