import { pgTable, text, serial, json } from "drizzle-orm/pg-core";
import { createInsertSchema } from "drizzle-zod";
import { z } from "zod";

export const users = pgTable("users", {
  id: serial("id").primaryKey(),
  username: text("username").notNull().unique(),
  password: text("password").notNull(), // Stores hashed color-character combinations
  colorPattern: json("color_pattern").notNull(), // Stores user's color selections
});

export const insertUserSchema = createInsertSchema(users).extend({
  confirmPassword: z.string(),
  colorPattern: z.array(z.object({
    color: z.string(),
    position: z.number()
  })).min(4).max(8)
}).omit({ id: true });

export type InsertUser = z.infer<typeof insertUserSchema>;
export type User = typeof users.$inferSelect;

export const loginSchema = z.object({
  username: z.string().min(3),
  pattern: z.array(z.object({
    color: z.string(),
    character: z.string(),
    position: z.number()
  }))
});

export type LoginData = z.infer<typeof loginSchema>;
